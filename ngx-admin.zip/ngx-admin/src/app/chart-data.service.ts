import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ChartDataService {

  constructor(private http: HttpClient) {}

  getPieChartData(data:any){
    return this.http.get('http://localhost:3000/agg-by-language-dates');
  }

  getDetailTransactions(data?:any){
    return this.http.get('http://localhost:3000/detail-transactions')
  }
  getUserData(data?:any){
    return this.http.get('http://localhost:3000/agg-by-user-dates')
  }
  getClientData(data?:any){
    return this.http.get('http://localhost:3000/agg-by-client-dates')
  }




}
