import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class ChartShareService {

  private chartDateSource = new BehaviorSubject<any>({start: new Date(), end: new Date()});
  chartDates = this.chartDateSource.asObservable()

  private pieChartDataSource = new BehaviorSubject<any>({start: new Date(), end: new Date()});
  pieChartData = this.pieChartDataSource.asObservable()

  private barChartDataSource = new BehaviorSubject<any>({start: new Date(), end: new Date()});
  barChartData = this.barChartDataSource.asObservable()

  private areaChartDataSource = new BehaviorSubject<any>({start: new Date(), end: new Date()});
  areaChartData = this.areaChartDataSource.asObservable()
  
  constructor() { }
  
  changechartDateSource(dates: any) {
    this.chartDateSource.next(dates);
  }

  changepieChartDataSource(data: any) {
    this.pieChartDataSource.next(data)
  }

  changebarChartDataSource(data: any) {
    this.barChartDataSource.next(data)
  }

  changeareaChartDataSource(data: any) {
    this.areaChartDataSource.next(data)
  }
}
