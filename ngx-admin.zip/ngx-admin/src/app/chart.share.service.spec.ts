import { TestBed } from '@angular/core/testing';

import { ChartShareService } from './chart.share.service';

describe('Chart.ShareService', () => {
  let service: ChartShareService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChartShareService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
