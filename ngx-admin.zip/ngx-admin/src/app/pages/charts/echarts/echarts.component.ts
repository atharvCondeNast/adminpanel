import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NbCalendarRange, NbDateService, NbDialogService } from '@nebular/theme';
import { ChartDataService } from '../../../chart-data.service';
import { ChartShareService } from '../../../chart.share.service';
import * as moment from "moment";
import { ShowcaseDialogComponent } from '../../modal-overlays/dialog/showcase-dialog/showcase-dialog.component';

@Component({
  selector: 'ngx-echarts',
  styleUrls: ['./echarts.component.scss'],
  templateUrl: './echarts.component.html',
  // entryComponents:[DayCellComponent]
})
export class EchartsComponent {

  date = new Date();
  date2 = new Date();
  range: NbCalendarRange<Date>;
  showDatePicker = false
  pieChartSpinner = true
  areaChartSpinner = true
  barChartSpinner = true
  chartResults = []
  // dayCellComponent = DayCellComponent;

  constructor(private _dialogService: NbDialogService, protected dateService: NbDateService<Date>, private _chartShareService: ChartShareService, private _chartDataService: ChartDataService, private _route: Router) {
    this.range = {
      start: new Date(),
      end: new Date(),
    };
    // Call the API here with todays date
    this._chartDataService.getPieChartData('').subscribe((result:any) => {
      this.chartResults = result;
      this.modifyForPie(result);
      this.modifyForBar(result);
      this.modifyForArea(result)
      this.pieChartSpinner = false
      this.areaChartSpinner = false
      this.barChartSpinner = false

    })
  }

  openDialog(title?){
    this._dialogService.open(ShowcaseDialogComponent, {
      context: {
        title: title ? title : [{name: 'This is a title passed to the dialog component', description:'This is a title passed to the dialog component'},
        {name: 'I am atharv',description:'This is a title passed to the dialog component'},
        {name: 'I an kalam',description:'This is a title passed to the dialog component'}],
      },
    });
  }

  getDaysBetweenDates (startDate, endDate) {
    var now = startDate.clone(), dates = [];
    now.add(1, 'days')
    endDate.add(1,'days')
    while (now.isSameOrBefore(endDate)) {
      dates.push(now.format('MM/DD/YYYY'));
      now.add(1, 'days');
    }
    return dates;
  };

  modifyForArea(data) {

    /**
     * [
            {
              name: 'Mail marketing',
              type: 'line',
              stack: 'Total amount',
              areaStyle: { normal: { opacity: echarts.areaOpacity } },
              data: [120, 132, 101, 134, 90, 230, 210],
            },
            {
              name: 'Affiliate advertising',
              type: 'line',
              stack: 'Total amount',
              areaStyle: { normal: { opacity: echarts.areaOpacity } },
              data: [220, 182, 191, 234, 290, 330, 310],
            },
            {
              name: 'Video ad',
              type: 'line',
              stack: 'Total amount',
              areaStyle: { normal: { opacity: echarts.areaOpacity } },
              data: [150, 232, 201, 154, 190, 330, 410],
            },
            {
              name: 'Direct interview',
              type: 'line',
              stack: 'Total amount',
              areaStyle: { normal: { opacity: echarts.areaOpacity } },
              data: [320, 332, 301, 334, 390, 330, 320],
            },
            {
              name: 'Search engine',
              type: 'line',
              stack: 'Total amount',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: echarts.textColor,
                  },
                },
              },
              areaStyle: { normal: { opacity: echarts.areaOpacity } },
              data: [820, 932, 901, 934, 1290, 1330, 1320],
            },
          ]
     */
    const legends = [];
    const seriesData = [];
    let xAxisVal = [];
    data.forEach(element => {
      legends.push(element.targetLanguage)
      const series = {
        name: element.targetLanguage,
        type: 'line',
        stack: 'Total amount',
        areaStyle: { normal: { opacity: echarts.areaOpacity } },
        data: [150, 232, 201, 154, 190, 330, 410],
      }
      seriesData.push(series)
      
    });
    const start = new Date(this.range.start).toISOString().split('T')[0]
    const end = new Date(this.range.end).toISOString().split('T')[0]
    if (start === end) {
      for (let index = 1; index < 8; index++) {
        xAxisVal.push(index.toString())
      }
    } else {
      xAxisVal = this.getDaysBetweenDates(moment(start), moment(end));
    }
    this._chartShareService.changeareaChartDataSource({ legends, seriesData, xAxisVal })
  }

  modifyForBar(data) {
    const legends = [];
    const seriesData = [];
    data.forEach(element => {
      legends.push(element.targetLanguage)
      seriesData.push(element.sumOfServiceMinute)
    });
    this._chartShareService.changebarChartDataSource({ legends, seriesData })
  }

  modifyForPie(data) {
    const legends = [];
    const seriesData = []
    data.forEach(element => {
      legends.push(element.targetLanguage)
      const series = { value: element.sumOfServiceMinute, name: element.targetLanguage }
      seriesData.push(series)
    });
    this._chartShareService.changepieChartDataSource({ legends, seriesData })

  }

  viewDetails(chartName) {
    const title = []
        this.chartResults.forEach(x=>{
          title.push({name: `Wait Time for ${x.targetLanguage}`,description:x.avergaeWaitTime })
          title.push({name: `Sum of Service Minutes for ${x.targetLanguage}`,description:x.sumOfServiceMinute })
          
        })
    switch (chartName) {
      case 'pie':
        
        this.openDialog(title)
        break;
      case 'bar':
        this.openDialog(title)
        break;
      case 'area':
        this.openDialog(title)
        break;

      default:
        break;
    }
  }

  resetSpinners() {
    this.pieChartSpinner = true
    this.areaChartSpinner = true
    this.barChartSpinner = true
  }

  datePicker() {
    this.showDatePicker = !this.showDatePicker
    if (!this.showDatePicker) {
      this.resetSpinners()
      // Call the API here with date range that is specified by user
      this._chartDataService.getPieChartData('').subscribe((result:any) => {
        this.chartResults = result;
        this.modifyForPie(result);
        this.modifyForBar(result);
        this.modifyForArea(result)
        this.pieChartSpinner = false
        this.areaChartSpinner = false
        this.barChartSpinner = false
      })
      this._chartShareService.changechartDateSource(this.range)
    }
  }

  get monthStart(): Date {
    return this.dateService.getMonthStart(new Date());
  }

  get monthEnd(): Date {
    return this.dateService.getMonthEnd(new Date());
  }
}
