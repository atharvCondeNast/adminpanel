import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LocalDataSource } from 'ng2-smart-table';

import { SmartTableData } from '../../../@core/data/smart-table';
import { ChartDataService } from '../../../chart-data.service';
import { ChartShareService } from '../../../chart.share.service';

@Component({
  selector: 'ngx-smart-table',
  templateUrl: './smart-table.component.html',
  styleUrls: ['./smart-table.component.scss'],
})
export class SmartTableComponent {

  settings:any = {
    actions: false,
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      "TransactionId": {
        title: 'TransactionId',
        type: 'string',
      },
      "ClientId": {
        title: 'ClientId',
        type: 'string',
      },
      "ClientName": {
        title: 'ClientName',
        type: 'string',
      },
      "UserId": {
        title: 'UserId',
        type: 'string',
      },
      "UserName": {
        title: 'UserName',
        type: 'string',
      },
      "Price": {
        title: 'Price',
        type: 'string',
      },
      "CallType": {
        title: 'Audio/Video/Asl',
        type: 'string',
      },
      "VideoOption": {
        title: 'Audio/Video',
        type: 'string',
      },
      "RequestType": {
        title: 'RequestType',
        type: 'string',
      },
      "SourceLanguage": {
        title: 'SourceLanguage',
        type: 'string',
      },
      "TargetLanguage": {
        title: 'TargetLanguage',
        type: 'string',
      },
      "CallerID": {
        title: 'CallerID',
        type: 'string',
      },
      "RequestTime": {
        title: 'RequestTime',
        type: 'string',
      },
      "WaitGreaterThan30Second": {
        title: 'Wait > 30 Seconds',
        type: 'string',
      },
      "WaitingSeconds": {
        title: 'WaitingSeconds',
        type: 'string',
      },
      "ServiceMinutes": {
        title: 'ServiceMinutes',
        type: 'string',
      }
    },
  };

  source: LocalDataSource = new LocalDataSource();
  currentRoute = ''
  result = [];
  clientData = []
  userData = []
  headerList = ["TransactionId",
  "ClientId",
  "ClientName",
  "UserId",
  "UserName",
  "Audio/Video",
  "Price",
  "Audio/Video/Asl",
  "RequestType",
  "SourceLanguage",
  "TargetLanguage",
  "CallerID",
  "RequestTime",
  "WaitGreaterThan30Second",
  "WaitingSeconds",
  "ServiceMinutes"]
  constructor(private service: SmartTableData, private _chartDataShare: ChartShareService, private _route: Router, private _ChartDataService: ChartDataService) {
    this._ChartDataService.getDetailTransactions().subscribe((result: any) => {
      this.defineSettingAndData(this._route.url)
      this.result = result;
      this.source.load(result);
    })


  }

  clientDetails() {
    this.headerList = [
      "ClientId",
      "ClientName",
      "date",
      "language",
      "targetLanguage",
      "year",
      "sumOfServiceMinute",
      "countTotalAudioVideoMinute",
      "avergaeWaitTime",
      "countAudioMinute",
      "countVideoMinute",
      "countFailedAudioRequest",
      "countSuccessAudioRequest",
      "countWaitTimeGreaterThan30",
      "countWaitTimeLessThan30",
      "countCallTotal"
    ]

    this.settings = {
      actions: false,
      add: {
        addButtonContent: '<i class="nb-plus"></i>',
        createButtonContent: '<i class="nb-checkmark"></i>',
        cancelButtonContent: '<i class="nb-close"></i>',
      },
      edit: {
        editButtonContent: '<i class="nb-edit"></i>',
        saveButtonContent: '<i class="nb-checkmark"></i>',
        cancelButtonContent: '<i class="nb-close"></i>',
      },
      delete: {
        deleteButtonContent: '<i class="nb-trash"></i>',
        confirmDelete: true,
      },
      columns: {
        "ClientId": {
          title: 'ClientId',
          type: 'string',
        },
        "ClientName": {
          title: 'ClientName',
          type: 'string',
        },
        "date": {
          title: 'date',
          type: 'string'
        },
        "language": {
          title: 'language',
          type: 'string',
        },
        "targetLanguage": {
          title: 'targetLanguage',
          type: 'string',
        },
        "year": {
          title: 'year',
          type: 'string',
        },
        "sumOfServiceMinute": {
          title: 'sumOfServiceMinute',
          type: 'string',
        },
        "countTotalAudioVideoMinute": {
          title: 'countTotalAudioVideoMinute',
          type: 'string',
        },
        "avergaeWaitTime": {
          title: 'avergaeWaitTime',
          type: 'string',
        },
        "countAudioMinute": {
          title: 'countAudioMinute',
          type: 'string',
        },
        "countVideoMinute": {
          title: 'countVideoMinute',
          type: 'string',
        },
        "countFailedAudioRequest": {
          title: 'countFailedAudioRequest',
          type: 'string',
        },
        "countSuccessAudioRequest": {
          title: 'countSuccessAudioRequest',
          type: 'string',
        },
        "countWaitTimeGreaterThan30": {
          title: 'countWaitTimeGreaterThan30',
          type: 'string',
        },
        "countWaitTimeLessThan30": {
          title: 'countWaitTimeLessThan30',
          type: 'string',
        },
        "countCallTotal": {
          title: 'countCallTotal',
          type: 'string',
        }
      },
    }

    this._ChartDataService.getClientData().subscribe((result: any) => {
      this.clientData = result;
      console.log("THIS IS CLINET ",result)
      this.source.load(result);
    })

  }
  userdetails() {
    this.headerList = ["UserId",
    "UserName",
    "date",
    "language",
    "targetLanguage",
    "year",
    "sumOfServiceMinute",
    "countTotalAudioVideoMinute",
    "avergaeWaitTime",
    "countAudioMinute",
    "countVideoMinute",
    "countFailedAudioRequest",
    "countSuccessAudioRequest",
    "countWaitTimeGreaterThan30",
    "countWaitTimeLessThan30",
    "countCallTotal"]
    this.settings = {
      actions: false,
      add: {
        addButtonContent: '<i class="nb-plus"></i>',
        createButtonContent: '<i class="nb-checkmark"></i>',
        cancelButtonContent: '<i class="nb-close"></i>',
      },
      edit: {
        editButtonContent: '<i class="nb-edit"></i>',
        saveButtonContent: '<i class="nb-checkmark"></i>',
        cancelButtonContent: '<i class="nb-close"></i>',
      },
      delete: {
        deleteButtonContent: '<i class="nb-trash"></i>',
        confirmDelete: true,
      },
      columns: {
        "UserId": {
          title: 'UserId',
          type: 'string',
        },
        "UserName": {
          title: 'UserName',
          type: 'string',
        },
        "date": {
          title: 'date',
          type: 'string'
        },
        "language": {
          title: 'language',
          type: 'string',
        },
        "targetLanguage": {
          title: 'targetLanguage',
          type: 'string',
        },
        "year": {
          title: 'year',
          type: 'string',
        },
        "sumOfServiceMinute": {
          title: 'sumOfServiceMinute',
          type: 'string',
        },
        "countTotalAudioVideoMinute": {
          title: 'countTotalAudioVideoMinute',
          type: 'string',
        },
        "avergaeWaitTime": {
          title: 'avergaeWaitTime',
          type: 'string',
        },
        "countAudioMinute": {
          title: 'countAudioMinute',
          type: 'string',
        },
        "countVideoMinute": {
          title: 'countVideoMinute',
          type: 'string',
        },
        "countFailedAudioRequest": {
          title: 'countFailedAudioRequest',
          type: 'string',
        },
        "countSuccessAudioRequest": {
          title: 'countSuccessAudioRequest',
          type: 'string',
        },
        "countWaitTimeGreaterThan30": {
          title: 'countWaitTimeGreaterThan30',
          type: 'string',
        },
        "countWaitTimeLessThan30": {
          title: 'countWaitTimeLessThan30',
          type: 'string',
        },
        "countCallTotal": {
          title: 'countCallTotal',
          type: 'string',
        }
      },
    }

    this._ChartDataService.getUserData().subscribe((result: any) => {
      this.userData = result;
      console.log("THIS IS userData ",result)

      this.source.load(result);
    })
  }
  defineSettingAndData(url) {
    this.currentRoute = url
    switch (url) {
      case '/pages/tables/client-table':
        this.clientDetails()
        break;
      case '/pages/tables/user-table':
        this.userdetails()
        break;

      default:
        break;
    }
  }
  download() {
    if(this.currentRoute === '/pages/tables/client-table'){
      this.downloadFile(this.clientData, new Date().toISOString().split('T')[0])

    } else if(this.currentRoute === '/pages/tables/user-table'){
      this.downloadFile(this.userData, new Date().toISOString().split('T')[0])
      
    }else{
      this.downloadFile(this.result, new Date().toISOString().split('T')[0])
    }
    
  }

  ConvertToCSV(objArray, headerList) {
    let array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    let row = 'S.No,';
    for (let index in headerList) {
      row += headerList[index] + ',';
    }
    row = row.slice(0, -1);
    str += row + '\r\n';
    for (let i = 0; i < array.length; i++) {
      let line = (i + 1) + '';
      for (let index in headerList) {
        let head = headerList[index];
        line += ',' + array[i][head];
      }
      str += line + '\r\n';
    }
    return str;
  }

  downloadFile(data, filename = 'data') {
    
    let csvData = this.ConvertToCSV(data,this.headerList)
    console.log(csvData)
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {  //if Safari open in new window to save file with random filename.
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  serviceByMinutePivot() {

  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }
}
